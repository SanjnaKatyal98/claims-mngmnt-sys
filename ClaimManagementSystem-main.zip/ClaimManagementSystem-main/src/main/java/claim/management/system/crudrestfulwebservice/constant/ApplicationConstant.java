package claim.management.system.crudrestfulwebservice.constant;

public class ApplicationConstant {
	public static String UPDATE_REQIEST = "UPDATE";
	public static String DELETE_REQUEST = "DELETE";
	
}
