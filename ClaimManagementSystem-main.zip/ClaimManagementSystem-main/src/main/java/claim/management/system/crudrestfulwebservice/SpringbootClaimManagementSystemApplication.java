package claim.management.system.crudrestfulwebservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootClaimManagementSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootClaimManagementSystemApplication.class, args);
	}

}
