package claim.management.system.crudrestfulwebservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootClaimManagementSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
